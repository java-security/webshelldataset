package agent;

public class Test {
    public void test(String s1,String s2){
        String s3;
        String s4;
        String s5;
        String s6;
        s3 = s1;
        s4 = s2;
        s5 = "11";
        s6 = s3;
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println(s5);
        System.out.println(s6);
    }
}
